'use client';

import { useState } from 'react';
import CompanyCard from './CompanyCard';
import CompanyDrawer from './CompanyDrawer';

interface Filing {
  id: string;
  fiscal_year: number;
  filing_date: string;
  total_revenue: number | null;
  net_income: number | null;
  total_assets: number | null;
  risk_keywords: string[];
}

interface Company {
  id: string;
  ticker: string;
  name: string;
  sector: string | null;
  cik: string;
  filings?: Filing[];
}

interface DashboardProps {
  companies: Company[];
}

export default function Dashboard({ companies }: DashboardProps) {
  const [selectedCompany, setSelectedCompany] = useState<Company | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleCardClick = (company: Company) => {
    setSelectedCompany(company);
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
    // Delay clearing company to allow animation to complete
    setTimeout(() => setSelectedCompany(null), 300);
  };

  // Calculate aggregate stats
  const totalFilings = companies.reduce(
    (acc, c) => acc + (c.filings?.length || 0),
    0
  );

  const companiesWithData = companies.filter(
    (c) => c.filings && c.filings.length > 0
  ).length;

  return (
    <>
      <main className="min-h-screen bg-gray-50">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-blue-900 to-blue-700 text-white">
          <div className="max-w-7xl mx-auto px-4 py-16 sm:px-6 lg:px-8">
            <h1 className="text-4xl font-bold mb-4">SEC EDGAR Analyzer</h1>
            <p className="text-xl text-blue-100 max-w-2xl">
              Financial metrics and risk analysis extracted from SEC 10-K filings.
              Explore revenue trends, profitability, and key risk factors across
              publicly traded companies.
            </p>

            {/* Stats */}
            <div className="mt-8 grid grid-cols-3 gap-8 max-w-lg">
              <div>
                <p className="text-3xl font-bold">{companies.length}</p>
                <p className="text-blue-200 text-sm">Companies</p>
              </div>
              <div>
                <p className="text-3xl font-bold">{totalFilings}</p>
                <p className="text-blue-200 text-sm">10-K Filings</p>
              </div>
              <div>
                <p className="text-3xl font-bold">{companiesWithData}</p>
                <p className="text-blue-200 text-sm">With Data</p>
              </div>
            </div>
          </div>
        </div>

        {/* Filters & Content */}
        <div className="max-w-7xl mx-auto px-4 py-8 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900">All Companies</h2>
            <p className="text-sm text-gray-500">
              Click any card to view detailed financials
            </p>
          </div>

          {/* Company Grid */}
          {companies.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {companies.map((company) => (
                <CompanyCard
                  key={company.id}
                  company={company}
                  onClick={handleCardClick}
                />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 bg-white rounded-lg shadow">
              <svg
                className="mx-auto h-12 w-12 text-gray-400"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={1.5}
                  d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                />
              </svg>
              <h3 className="mt-4 text-lg font-medium text-gray-900">
                No companies found
              </h3>
              <p className="mt-2 text-gray-500">
                Run the ingestion script to populate data from SEC EDGAR.
              </p>
              <div className="mt-4 bg-gray-50 rounded p-4 max-w-md mx-auto">
                <code className="text-sm text-gray-600">
                  python scripts/ingest_filings.py
                </code>
              </div>
            </div>
          )}

          {/* Data Source Footer */}
          <div className="mt-12 pt-8 border-t border-gray-200 text-center">
            <p className="text-sm text-gray-500">
              Data sourced from{' '}
              <a
                href="https://www.sec.gov/edgar"
                target="_blank"
                rel="noopener noreferrer"
                className="text-blue-600 hover:underline"
              >
                SEC EDGAR
              </a>
              {' '}• Last updated automatically via ETL pipeline
            </p>
          </div>
        </div>
      </main>

      {/* Drawer */}
      <CompanyDrawer
        company={selectedCompany}
        isOpen={isDrawerOpen}
        onClose={handleCloseDrawer}
      />
    </>
  );
}
