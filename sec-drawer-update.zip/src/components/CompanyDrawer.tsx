'use client';

import { useEffect } from 'react';
import FinancialChart from './FinancialChart';
import RiskKeywords from './RiskKeywords';

interface Filing {
  id: string;
  fiscal_year: number;
  filing_date: string;
  total_revenue: number | null;
  net_income: number | null;
  total_assets: number | null;
  risk_keywords: string[];
  filing_url?: string;
}

interface Company {
  id: string;
  ticker: string;
  name: string;
  sector: string | null;
  cik: string;
  filings?: Filing[];
}

interface CompanyDrawerProps {
  company: Company | null;
  isOpen: boolean;
  onClose: () => void;
}

function formatCurrency(value: number | null): string {
  if (value === null) return 'N/A';
  if (Math.abs(value) >= 1e9) {
    return `$${(value / 1e9).toFixed(2)}B`;
  }
  if (Math.abs(value) >= 1e6) {
    return `$${(value / 1e6).toFixed(2)}M`;
  }
  return `$${value.toLocaleString()}`;
}

function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export default function CompanyDrawer({ company, isOpen, onClose }: CompanyDrawerProps) {
  // Close on Escape key
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    
    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }
    
    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!company) return null;

  const sortedFilings = company.filings?.slice().sort((a, b) => a.fiscal_year - b.fiscal_year) || [];
  const latestFiling = sortedFilings[sortedFilings.length - 1];
  const previousFiling = sortedFilings[sortedFilings.length - 2];

  const revenueGrowth =
    latestFiling?.total_revenue && previousFiling?.total_revenue
      ? (((latestFiling.total_revenue - previousFiling.total_revenue) / previousFiling.total_revenue) * 100).toFixed(1)
      : null;

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black transition-opacity duration-300 z-40 ${
          isOpen ? 'opacity-50' : 'opacity-0 pointer-events-none'
        }`}
        onClick={onClose}
      />

      {/* Drawer */}
      <div
        className={`fixed right-0 top-0 h-full w-full max-w-4xl bg-gray-50 shadow-2xl z-50 transform transition-transform duration-300 ease-in-out overflow-y-auto ${
          isOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex justify-between items-start z-10">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold text-gray-900">{company.ticker}</h2>
              {company.sector && (
                <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                  {company.sector}
                </span>
              )}
            </div>
            <p className="text-gray-600 mt-1">{company.name}</p>
            <p className="text-sm text-gray-400">CIK: {company.cik}</p>
          </div>
          
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            aria-label="Close"
          >
            <svg className="w-6 h-6 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          {/* Key Metrics */}
          {latestFiling && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-sm text-gray-500">Revenue (FY{latestFiling.fiscal_year})</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(latestFiling.total_revenue)}
                </p>
                {revenueGrowth && (
                  <p className={`text-sm ${parseFloat(revenueGrowth) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {parseFloat(revenueGrowth) >= 0 ? '↑' : '↓'} {Math.abs(parseFloat(revenueGrowth))}% YoY
                  </p>
                )}
              </div>

              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-sm text-gray-500">Net Income</p>
                <p className={`text-2xl font-bold ${
                  latestFiling.net_income && latestFiling.net_income > 0 ? 'text-green-600' : 'text-red-600'
                }`}>
                  {formatCurrency(latestFiling.net_income)}
                </p>
              </div>

              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-sm text-gray-500">Total Assets</p>
                <p className="text-2xl font-bold text-gray-900">
                  {formatCurrency(latestFiling.total_assets)}
                </p>
              </div>

              <div className="bg-white rounded-lg shadow p-4">
                <p className="text-sm text-gray-500">Profit Margin</p>
                <p className={`text-2xl font-bold ${
                  latestFiling.total_revenue && latestFiling.net_income &&
                  (latestFiling.net_income / latestFiling.total_revenue) > 0
                    ? 'text-green-600'
                    : 'text-red-600'
                }`}>
                  {latestFiling.total_revenue && latestFiling.net_income
                    ? `${((latestFiling.net_income / latestFiling.total_revenue) * 100).toFixed(1)}%`
                    : 'N/A'}
                </p>
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Charts */}
            <div className="lg:col-span-2 space-y-6">
              {sortedFilings.length > 0 && (
                <FinancialChart filings={sortedFilings} />
              )}
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Risk Keywords */}
              {latestFiling?.risk_keywords && latestFiling.risk_keywords.length > 0 && (
                <RiskKeywords keywords={latestFiling.risk_keywords} />
              )}

              {/* Filing History */}
              <div className="bg-white rounded-lg shadow p-6">
                <h3 className="font-semibold text-gray-900 mb-4">Filing History</h3>
                <div className="space-y-3">
                  {sortedFilings.slice().reverse().map((filing) => (
                    <div
                      key={filing.id}
                      className="flex justify-between items-center py-2 border-b border-gray-100 last:border-0"
                    >
                      <div>
                        <p className="font-medium text-gray-900">FY {filing.fiscal_year}</p>
                        <p className="text-xs text-gray-500">Filed {formatDate(filing.filing_date)}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-gray-900">
                          {formatCurrency(filing.total_revenue)}
                        </p>
                        <p className={`text-xs ${filing.net_income && filing.net_income > 0 ? 'text-green-600' : 'text-red-600'}`}>
                          {formatCurrency(filing.net_income)}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
